(() => {
  if (window.KITRADE_CATALOG_DATA) return;
  const source = "catalog-runtime-data.js?v=4";
  // Resolve against the loader script, including srcdoc with a base URL.
  const base = document.currentScript?.src || document.baseURI;
  const url = new URL(source, base).href;
  document.write('<script src="' + url + '"><\/script>');
})();
