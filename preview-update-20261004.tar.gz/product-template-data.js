(() => {
  const base = String(window.KITRADE_SITE_CONFIG?.basePath || '').replace(/\/$/, '');
  const sitePath = (value) => {
    if (window.KITRADE_SITE_PATH) return window.KITRADE_SITE_PATH(value);
    return base && value.startsWith('/') && !value.startsWith(base + '/') ? base + value : value;
  };
  const requestedPath = new URLSearchParams(location.search).get('route');
  const pathname = base && location.pathname.startsWith(base + '/')
    ? location.pathname.slice(base.length) : location.pathname;
  const path = requestedPath || (/^\/catalog\/product\/[^/]+\/$/.test(pathname)
    ? pathname : '/catalog/product/perednyaya-fara-levaya-aito-m8-1004/');
  // Published product pages already contain their complete gallery and data.
  // Keep those nodes, including thumbnails, instead of rebuilding the template.
  if (!requestedPath && /^\/catalog\/product\/[^/]+\/$/.test(pathname)) {
    try {
      const data = JSON.parse(document.querySelector('#product-page-data')?.textContent || 'null');
      if (data?.canonical_path === path) return;
    } catch {}
  }
  const product = [...(window.KITRADE_CATALOG_DATA?.items || []), ...(window.KITRADE_ARCHIVED_PRODUCTS || [])]
    .find((item) => item.canonical_path === path);
  if (!product) {
    document.querySelector('.product-page-layout')?.replaceChildren(Object.assign(document.createElement('h1'), { textContent: 'Товар не найден' }));
    document.querySelector('#product-page-data')?.remove();
    return;
  }

  const text = (selector, value) => {
    const element = document.querySelector(selector);
    if (element) element.textContent = value;
  };
  const money = (value) => new Intl.NumberFormat('ru-RU').format(Number(value) || 0) + ' ₽';
  const category = product.public_category || product.category || 'Автозапчасти';
  const years = product.yearFrom && product.yearTo ? `${product.yearFrom}–${product.yearTo}` : 'Уточняются';
  const summary = [product.brand, product.model, product.article && `OEM ${product.article}`, product.condition].filter(Boolean).join(' · ');
  const description = `${product.title}. ${product.article ? `OEM — ${product.article}. ` : ''}Состояние — ${(product.condition || 'новое').toLowerCase()}. Совместимость: ${product.brand} ${product.model}${product.generation ? `, поколение ${product.generation}` : ''}, ${years} г. Цена детали — ${money(product.price)}; доставка из Китая рассчитывается отдельно. Совместимость проверим по VIN.`;

  document.title = `${product.title}${product.article ? `, ${product.article}` : ''} | KITRADE`;
  const descriptionMeta = document.querySelector('meta[name="description"]');
  if (descriptionMeta) descriptionMeta.content = `Цена указана за деталь; доставка рассчитывается отдельно. Проверка по VIN. ${product.title}${product.article ? `. OEM ${product.article}` : ''}.`;
  const canonical = document.querySelector('link[rel="canonical"]');
  if (canonical) canonical.href = new URL(path, window.KITRADE_CATALOG_DATA.site_url).href;
  document.querySelectorAll('meta[property="og:title"]').forEach((node) => node.content = document.title);
  document.querySelectorAll('meta[property="og:description"]').forEach((node) => node.content = descriptionMeta?.content || '');
  document.querySelectorAll('meta[property="og:url"]').forEach((node) => node.content = canonical?.href || '');

  text('.product-page-content > .product-page-category', category);
  text('.product-page-content > h1', product.title);
  text('.product-page-meta', summary);
  text('.product-page-price', money(product.price));
  text('.product-page-description', description);
  const specs = document.querySelector('.product-page-specs');
  if (specs) {
    const values = [product.brand, product.model, product.generation || 'Уточняется', years, product.article || 'Уточняется', product.condition || 'Новое'];
    specs.querySelectorAll('dd').forEach((node, index) => node.textContent = values[index]);
  }
  const gallery = document.querySelector('.product-page-gallery');
  if (gallery) {
    gallery.replaceChildren();
    const photo = product.photos?.[0];
    const isLegacyAvitoPhoto = /(?:^|\.)avito\.st(?:\/|$)/i.test(String(photo || ''));
    if (photo && !isLegacyAvitoPhoto) {
      const image = document.createElement('img');
      image.src = photo.startsWith('/') ? sitePath(photo) : photo;
      image.alt = product.title;
      gallery.append(image);
    } else gallery.textContent = 'Фото отсутствует';
  }
  const crumbs = document.querySelector('.catalog-breadcrumbs');
  if (crumbs) {
    crumbs.replaceChildren();
    const routes = window.KITRADE_CATALOG_DATA.routes || {};
    const brand = product.brand?.toLocaleLowerCase('ru');
    const model = product.model?.toLocaleLowerCase('ru');
    const part = category.toLocaleLowerCase('ru');
    const links = [['Главная', '/'], ['Каталог', '/catalog/'],
      [product.brand, routes.brands?.[brand]],
      [product.model, routes.models?.[`${brand}|${model}`]],
      [category, routes.categories?.[`${brand}|${model}|${part}`]]].filter(([, href]) => href);
    links.forEach(([label, href]) => {
      const a = document.createElement('a');
      a.href = sitePath(href);
      a.textContent = label;
      crumbs.append(a, Object.assign(document.createElement('span'), { textContent: '/' }));
    });
    const current = document.createElement('span');
    current.setAttribute('aria-current', 'page');
    current.textContent = product.title;
    crumbs.append(current);
  }
  const payload = {
    id: product.id,
    title: product.title,
    article: product.article || '',
    price: Number(product.price) || 0,
    canonical_path: product.canonical_path,
    photos: product.photos || []
  };
  const dataNode = document.querySelector('#product-page-data');
  if (dataNode) dataNode.textContent = JSON.stringify(payload);
  document.querySelectorAll('script[type="application/ld+json"]').forEach((node) => node.remove());
})();
